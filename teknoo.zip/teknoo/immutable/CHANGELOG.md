#Teknoo Software - Immutable library - Change Log

##[0.0.1] - 2016-07-26
- First release

###Added
- Add api doc

##[0.0.1-beta1] - 2016-04-09
- First Beta

###Fixed
- Fix code style with cs-fixer

##[0.0.1-alpha1] - 2016-02-25
- First alpha

###Added
- ImmutableInterface
- ImmutableTrait with default constructor
- Tests
